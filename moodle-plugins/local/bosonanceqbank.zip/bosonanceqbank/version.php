<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_bosonanceqbank';
$plugin->version = 2026112400;
$plugin->requires = 2026100501;
$plugin->maturity = MATURITY_ALPHA;
$plugin->release = '0.4.0';
